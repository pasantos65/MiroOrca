<div align="center">

<img src="static/image/miroorca-logo.png" alt="MiroOrca Logo" width="180"/>

# MiroOrca

**Universal Swarm Intelligence Engine**

*Feed reality seeds. Simulate the world's reaction. Predict what happens next.*

[![License: AGPL-3.0](https://img.shields.io/badge/License-AGPL--3.0-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.11%2B-green.svg)](https://python.org)
[![Node.js](https://img.shields.io/badge/Node.js-18%2B-green.svg)](https://nodejs.org)
[![Docker](https://img.shields.io/badge/Docker-Supported-blue.svg)](docker-compose.yml)
[![English](https://img.shields.io/badge/Language-English--First-orange.svg)](#)

[Quick Start](#-quick-start) · [How It Works](#-how-it-works) · [Use Cases](#-use-cases) · [Configuration](#-configuration) · [Credits](#-credits)

---

![MiroOrca Demo](static/image/miroorca-demo.gif)

</div>

---

## What Is MiroOrca?

MiroOrca is an **English-first** swarm intelligence engine that builds a living simulation of how people respond to ideas.

You upload a document — a news article, a policy draft, a press release, a book premise, a financial report — and describe what you want to predict in plain English. MiroOrca then:

1. **Extracts** the entities, relationships, and themes from your content into a knowledge graph
2. **Generates** hundreds of AI agents, each with a unique personality, platform, and opinion bias
3. **Runs** them through multiple rounds of social interaction across simulated Twitter-like and Reddit-like platforms
4. **Produces** a structured prediction report and lets you interview any agent directly

The result is not a poll. It is a simulation of how an idea *moves* through a real digital population — the arguments it triggers, the opinions it shifts, the controversies it surfaces.

---

## ✨ Features

- 🌊 **Multi-round social simulation** — agents react to each other, not just your content
- 🧠 **Knowledge graph grounding** — entities extracted from your document give agents shared context
- 👤 **Hundreds of unique personas** — each agent has personality, platform, influence level, and opinion bias
- 📊 **Rich prediction report** — sentiment arc, key controversies, most influential agents, verdict
- 💬 **Deep interaction mode** — chat with any agent or the ReportAgent post-simulation
- 🔌 **Any LLM** — OpenAI, Anthropic Claude, Google Gemini, local Ollama, or any OpenAI-compatible API
- 🏠 **Local-first** — Neo4j runs on your machine; no mandatory cloud services
- ⏸️ **Pause / Resume / Restart** — full simulation control
- 🎨 **Modern dark UI** — redesigned step-by-step wizard interface
- 🐳 **One-command Docker setup** — up and running in minutes

---

## 🚀 Quick Start

### Option A — Docker (Recommended, no setup required)

```bash
git clone https://github.com/YOUR_USERNAME/MiroOrca.git
cd MiroOrca

# Configure your environment
cp .env.example .env
# Edit .env with your API key (see Configuration section)

# Start everything
docker compose up -d
```

Open **http://localhost:3000** — that's it.

---

### Option B — Cloud API + Local Neo4j

Requires: Python 3.11+, Node.js 18+, Docker (for Neo4j only)

```bash
# 1. Start Neo4j
docker run -d --name neo4j \
  -p 7474:7474 -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/miroorca \
  neo4j:5.15-community

# 2. Clone and configure
git clone https://github.com/YOUR_USERNAME/MiroOrca.git
cd MiroOrca
cp .env.example .env
# Edit .env — add your LLM API key

# 3. Install all dependencies
npm run setup:all

# 4. Start
npm run dev
```

**Frontend:** http://localhost:3000  
**Backend API:** http://localhost:5001

---

### Option C — Fully Local (Ollama, no API costs)

```bash
# 1. Install and start Ollama
ollama serve &
ollama pull qwen2.5:14b          # Main LLM
ollama pull nomic-embed-text     # Embeddings

# 2. Start Neo4j
docker run -d --name neo4j \
  -p 7474:7474 -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/miroorca \
  neo4j:5.15-community

# 3. Clone and configure
git clone https://github.com/YOUR_USERNAME/MiroOrca.git
cd MiroOrca
cp .env.example .env
# Set LLM_BASE_URL=http://localhost:11434/v1 and LLM_API_KEY=ollama

# 4. Install and run
npm run setup:all && npm run dev
```

---

## 🔄 How It Works

MiroOrca runs a structured **5-stage simulation lifecycle**:

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   1. GRAPH BUILD     Upload document → extract knowledge graph  │
│         ↓                                                       │
│   2. AGENT SETUP     Generate personas from the graph           │
│         ↓                                                       │
│   3. SIMULATION      Multi-round social interaction             │
│         ↓                                                       │
│   4. REPORT          AI analyzes logs → prediction report       │
│         ↓                                                       │
│   5. INTERACT        Chat with agents or the ReportAgent        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Stage 1 — Graph Build
Upload any document (PDF, Markdown, or plain text, up to 50MB). The LLM extracts entities — people, organizations, themes, tensions — and builds a Neo4j knowledge graph. This gives all agents shared, structured context rather than raw text.

### Stage 2 — Agent Setup
From the knowledge graph, MiroOrca generates N unique agent personas. Each agent receives:
- A name, age range, and demographic background
- A home platform (Twitter-like or Reddit-like)
- A personality type (skeptic, enthusiast, analyst, lurker, influencer...)
- An opinion bias and reaction speed
- An influence score that determines how much they sway others

You can review and edit all personas before running.

### Stage 3 — Simulation
The OASIS multi-agent engine runs agents through multiple rounds of social interaction. Agents post, reply, argue, agree, and shift opinions. Each round, agents read what previous rounds produced — emergent opinion dynamics develop naturally. You can watch the live feed, pause, resume, or restart at any time.

### Stage 4 — Report
The ReportAgent uses a ReACT reasoning loop to analyze all simulation logs and generates a structured report including:
- Sentiment arc across rounds (how opinion evolved)
- Most influential agents and their effect
- Key controversy clusters
- Platform breakdowns (Twitter-like vs Reddit-like)
- A verdict with confidence score and recommended actions

### Stage 5 — Deep Interaction
Post-simulation, you can chat with any individual agent ("What made you change your mind in round 3?") or query the ReportAgent for follow-up analysis.

---

## 🎯 Use Cases

| Scenario | What You Feed It | What You Get |
|---|---|---|
| **PR Crisis Testing** | Draft press release | Simulated public reaction before publishing |
| **Policy Analysis** | Draft regulation text | How different communities respond over time |
| **Book / Content Testing** | Synopsis or excerpt | Reader response prediction, controversy radar |
| **Product Launch** | Announcement draft | Sentiment arc, likely criticisms, fan segments |
| **Financial Analysis** | Earnings report or news | Simulated market sentiment evolution |
| **Creative Writing** | Novel premise or lost ending | Character-consistent narrative deduction |

---

## ⚙️ Configuration

All settings live in `.env` (copy from `.env.example`):

```env
# ── LLM Configuration ─────────────────────────────────────────────
# Supports any OpenAI-compatible API
LLM_API_KEY=your_api_key_here
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL_NAME=gpt-4o-mini

# ── Smart Model (optional) ────────────────────────────────────────
# Routes intelligence-heavy tasks (report generation, ontology
# extraction) to a stronger model while keeping simulation rounds
# on the faster/cheaper default model
# SMART_MODEL_NAME=gpt-4o
# SMART_API_KEY=your_smart_key       # only if different provider
# SMART_BASE_URL=https://...         # only if different provider

# ── Neo4j Graph Database ──────────────────────────────────────────
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=miroorca

# ── Embeddings ────────────────────────────────────────────────────
EMBEDDING_MODEL=text-embedding-3-small
EMBEDDING_DIMENSIONS=768

# ── Application ───────────────────────────────────────────────────
SECRET_KEY=change-this-in-production
FLASK_DEBUG=True
```

### Recommended LLM Options

**Cloud (API key required):**

| Provider | Model | Cost/simulation | Notes |
|---|---|---|---|
| OpenAI | `gpt-4o-mini` | ~$0.20 | Fast, reliable default |
| Anthropic | `claude-haiku-4-5` | ~$0.15 | Excellent for simulation rounds |
| OpenRouter | `qwen/qwen3-235b` | ~$0.30 | Best quality overall |
| Google | `gemini-2.5-flash-lite` | ~$0.25 | Good alternative |

**Local (Ollama, free after setup):**

| Model | VRAM | Notes |
|---|---|---|
| `qwen2.5:14b` | 12 GB | Solid balance of speed and quality |
| `qwen2.5:7b` | 8 GB | Minimum viable |
| `llama3.1:8b` | 8 GB | Good English language performance |

**Smart Model tip:** Set `LLM_MODEL_NAME` to a fast/cheap model for the high-volume simulation rounds, and `SMART_MODEL_NAME` to a stronger model for report generation and knowledge graph extraction. Most users cut costs by 60–80% this way.

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| **Frontend** | Vue.js 3, Vite, Tailwind CSS, D3.js |
| **Backend** | Python 3.11+, Flask, uv |
| **Graph Database** | Neo4j 5.15+ (local Docker) |
| **Simulation Engine** | OASIS by CAMEL-AI |
| **LLM Orchestration** | OpenAI-compatible SDK |
| **Containerization** | Docker + Docker Compose |

---

## 📁 Project Structure

```
MiroOrca/
├── README.md
├── QUICKSTART.md
├── CREDITS.md
├── LICENSE
├── .env.example
├── docker-compose.yml
├── Dockerfile
├── package.json
│
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── graph.py          # /api/graph  — document ingestion
│   │   │   ├── simulation.py     # /api/simulation — run control
│   │   │   └── report.py         # /api/report — analysis + chat
│   │   ├── services/
│   │   │   ├── ontology_generator.py
│   │   │   ├── graph_builder.py
│   │   │   ├── profile_generator.py
│   │   │   ├── simulation_runner.py
│   │   │   └── report_agent.py
│   │   ├── models/
│   │   │   └── task.py
│   │   ├── utils/
│   │   │   ├── logger.py
│   │   │   └── llm_client.py
│   │   ├── __init__.py
│   │   └── config.py
│   ├── scripts/
│   ├── run.py
│   └── pyproject.toml
│
├── frontend/
│   ├── src/
│   │   ├── views/
│   │   │   ├── Home.vue
│   │   │   ├── GraphBuild.vue
│   │   │   ├── AgentSetup.vue
│   │   │   ├── SimulationRun.vue
│   │   │   ├── Report.vue
│   │   │   └── Chat.vue
│   │   ├── components/
│   │   │   ├── AgentCard.vue
│   │   │   ├── SimulationFeed.vue
│   │   │   ├── GraphVisualizer.vue
│   │   │   ├── SentimentChart.vue
│   │   │   └── StepWizard.vue
│   │   └── api/
│   │       └── client.js
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
├── static/
│   └── image/
│
└── docs/
    ├── setup.md
    ├── configuration.md
    ├── use-cases.md
    └── architecture.md
```

---

## 🗺 Roadmap

- [x] English-first codebase (no Chinese strings)
- [x] Neo4j local graph database (no Zep Cloud dependency)
- [x] Docker one-command setup
- [x] Smart model routing (cheap model for simulation, strong model for reports)
- [x] Pause / Resume / Restart simulation
- [ ] Redesigned dark-mode UI
- [ ] Persona template library (presets for common simulation types)
- [ ] Export report as PDF
- [ ] Simulation comparison (run same content with different persona sets)
- [ ] REST API documentation (OpenAPI/Swagger)
- [ ] Web-based configuration editor (no manual `.env` editing)

---

## 🤝 Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

For bugs and feature requests, open an [Issue](../../issues).

---

## 📜 Credits

MiroOrca is built on the shoulders of excellent open-source work:

| Project | Author | Role |
|---|---|---|
| [MiroFish](https://github.com/666ghj/MiroFish) | 666ghj / Shanda Group | Original swarm engine |
| [MiroShark](https://github.com/aaronjmars/MiroShark) | aaronjmars | English fork + Neo4j storage |
| [MiroFish-Offline](https://github.com/nikmcfly/MiroFish-Offline) | nikmcfly | Offline/local architecture |
| [OASIS](https://github.com/camel-ai/oasis) | CAMEL-AI | Multi-agent simulation engine |

---

## 📄 License

MiroOrca is licensed under the **GNU Affero General Public License v3.0** (AGPL-3.0).

This means: you can use, modify, and distribute this software freely, but any modifications you deploy as a network service must also be made open source under the same license.

See [LICENSE](LICENSE) for full details.

---

<div align="center">

*Built with 🌊 — predict anything*

</div>
